#ifndef STRINT_H
#define STRINT_H

char* si_add(char* xx, char* yy);

#endif
