echo banana > test2a.txt
false && echo apple > test2a.txt
echo split > test2b.txt
cat test2a.txt test2b.txt
status sh test4.sh
true
